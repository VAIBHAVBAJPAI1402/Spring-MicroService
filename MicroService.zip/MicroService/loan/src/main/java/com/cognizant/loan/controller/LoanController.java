package com.cognizant.loan.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.loan.model.Loan;

@RestController
public class LoanController {
	@GetMapping("/loan/{number}")
	public String getLoan(@PathVariable int number) {
		Loan loan=new Loan("H0098765432104","car",400000,3258,18);
		return loan.toString();
	}
}
